#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ class Detector+;
#pragma link C++ class vector<Detector>+;
#pragma link C++ class GriffinDetector+;
#pragma link C++ class vector<GriffinDetector>+;
#pragma link C++ class GriffinBgo+;
#pragma link C++ class vector<GriffinBgo>+;
#endif
