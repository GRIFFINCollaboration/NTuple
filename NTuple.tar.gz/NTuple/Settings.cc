#include "Settings.hh"

#include "TEnv.h"
#include "TString.h"

Settings::Settings(std::string fileName, int verbosityLevel)
  : fVerbosityLevel(verbosityLevel) {
  TEnv env;
  env.Read(fileName.c_str());

  fBufferSize = env.GetValue("BufferSize",1024000);

  fResolution[1000].resize(16,std::vector<double>(4)); 
  fThreshold[1000].resize(16,std::vector<double>(4)); 
  fThresholdWidth[1000].resize(16,std::vector<double>(4)); 

  fResolution[1100].resize(16,std::vector<double>(4)); 
  fThreshold[1100].resize(16,std::vector<double>(4)); 
  fThresholdWidth[1100].resize(16,std::vector<double>(4)); 

  fResolution[1200].resize(16,std::vector<double>(4)); 
  fThreshold[1200].resize(16,std::vector<double>(4)); 
  fThresholdWidth[1200].resize(16,std::vector<double>(4)); 

  fResolution[1300].resize(16,std::vector<double>(4)); 
  fThreshold[1300].resize(16,std::vector<double>(4)); 
  fThresholdWidth[1300].resize(16,std::vector<double>(4)); 

  fResolution[1400].resize(16,std::vector<double>(4)); 
  fThreshold[1400].resize(16,std::vector<double>(4)); 
  fThresholdWidth[1400].resize(16,std::vector<double>(4)); 

  fResolution[1500].resize(16,std::vector<double>(4)); 
  fThreshold[1500].resize(16,std::vector<double>(4)); 
  fThresholdWidth[1500].resize(16,std::vector<double>(4)); 

  for(int detector = 0; detector < 16; ++detector) {
    for(int crystal = 0; crystal < 4; ++crystal) {
      fResolution[1000][detector][crystal] = env.GetValue(Form("Griffin.%d.%d.Resolution.keV",detector,crystal),2.);
      fThreshold[1000][detector][crystal] = env.GetValue(Form("Griffin.%d.%d.Threshold.keV",detector,crystal),10.);
      fThresholdWidth[1000][detector][crystal] = env.GetValue(Form("Griffin.%d.%d.ThresholdWidth.keV",detector,crystal),2.);

      fResolution[1100][detector][crystal] = env.GetValue(Form("Griffin.BGO.Front.Left.%d.%d.Resolution.keV",detector,crystal),2.);
      fThreshold[1100][detector][crystal] = env.GetValue(Form("Griffin.BGO.Front.Left.%d.%d.Threshold.keV",detector,crystal),10.);
      fThresholdWidth[1100][detector][crystal] = env.GetValue(Form("Griffin.BGO.Front.Left.%d.%d.ThresholdWidth.keV",detector,crystal),2.);

      fResolution[1200][detector][crystal] = env.GetValue(Form("Griffin.BGO.Front.Right.%d.%d.Resolution.keV",detector,crystal),2.);
      fThreshold[1200][detector][crystal] = env.GetValue(Form("Griffin.BGO.Front.Right.%d.%d.Threshold.keV",detector,crystal),10.);
      fThresholdWidth[1200][detector][crystal] = env.GetValue(Form("Griffin.BGO.Front.Right.%d.%d.ThresholdWidth.keV",detector,crystal),2.);

      fResolution[1300][detector][crystal] = env.GetValue(Form("Griffin.BGO.Side.Left.%d.%d.Resolution.keV",detector,crystal),2.);
      fThreshold[1300][detector][crystal] = env.GetValue(Form("Griffin.BGO.Side.Left.%d.%d.Threshold.keV",detector,crystal),10.);
      fThresholdWidth[1300][detector][crystal] = env.GetValue(Form("Griffin.BGO.Side.Left.%d.%d.ThresholdWidth.keV",detector,crystal),2.);

      fResolution[1400][detector][crystal] = env.GetValue(Form("Griffin.BGO.Side.Right.%d.%d.Resolution.keV",detector,crystal),2.);
      fThreshold[1400][detector][crystal] = env.GetValue(Form("Griffin.BGO.Side.Right.%d.%d.Threshold.keV",detector,crystal),10.);
      fThresholdWidth[1400][detector][crystal] = env.GetValue(Form("Griffin.BGO.Side.Right.%d.%d.ThresholdWidth.keV",detector,crystal),2.);

      fResolution[1500][detector][crystal] = env.GetValue(Form("Griffin.BGO.Back.%d.%d.Resolution.keV",detector,crystal),2.);
      fThreshold[1500][detector][crystal] = env.GetValue(Form("Griffin.BGO.Back.%d.%d.Threshold.keV",detector,crystal),10.);
      fThresholdWidth[1500][detector][crystal] = env.GetValue(Form("Griffin.BGO.Back.%d.%d.ThresholdWidth.keV",detector,crystal),2.);
    }
  }

  fNofBins["Statistics"] = env.GetValue("Histogram.Statistics.NofBins",16);
  fRangeLow["Statistics"] = env.GetValue("Histogram.Statistics.RangeLow.keV",0.);
  fRangeHigh["Statistics"] = env.GetValue("Histogram.Statistics.RangeHigh.keV",16.);

  fNofBins["Griffin1D"] = env.GetValue("Histogram.1D.Griffin.NofBins",10000);
  fRangeLow["Griffin1D"] = env.GetValue("Histogram.1D.Griffin.RangeLow.keV",0.);
  fRangeHigh["Griffin1D"] = env.GetValue("Histogram.1D.Griffin.RangeHigh.keV",10000.);

  fNofBins["Griffin2D"] = env.GetValue("Histogram.2D.Griffin.NofBins",1000);
  fRangeLow["Griffin2D"] = env.GetValue("Histogram.2D.Griffin.RangeLow.keV",0.);
  fRangeHigh["Griffin2D"] = env.GetValue("Histogram.2D.Griffin.RangeHigh.keV",10000.);
}
