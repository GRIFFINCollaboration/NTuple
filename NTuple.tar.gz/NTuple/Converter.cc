#include "Converter.hh"

#include <iostream>
#include <iomanip>

#include "TMath.h"

#include "Utilities.hh"

Converter::Converter(std::vector<std::string>& inputFileNames, const std::string& outputFileName, Settings* settings)
  : fSettings(settings) {
  //create TChain to read in all input files
  for(auto& fileName : inputFileNames) {
    if(!FileExists(fileName)) {
      std::cerr<<"Failed to find file '"<<fileName<<"', skipping it!"<<std::endl;
      continue;
    }
    //add sub-directory and tree name to file name
    fileName.append("/ntuple/ntuple");
    fChain.Add(fileName.c_str());
  }

  //add branches to input chain
  fChain.SetBranchAddress("eventNumber", &fEventNumber);
  fChain.SetBranchAddress("trackID", &fTrackID);
  fChain.SetBranchAddress("parentID", &fParentID);
  fChain.SetBranchAddress("stepNumber", &fStepNumber);
  fChain.SetBranchAddress("particleType", &fParticleType);
  fChain.SetBranchAddress("processType", &fProcessType);
  fChain.SetBranchAddress("systemID", &fSystemID);
  fChain.SetBranchAddress("detNumber", &fDetNumber);
  fChain.SetBranchAddress("cryNumber", &fCryNumber);
  fChain.SetBranchAddress("depEnergy", &fDepEnergy);
  fChain.SetBranchAddress("posx", &fPosx);
  fChain.SetBranchAddress("posy", &fPosy);
  fChain.SetBranchAddress("posz", &fPosz);
  fChain.SetBranchAddress("time", &fTime);

  //create output file
  fOutput = new TFile(outputFileName.c_str(),"recreate");
  if(!fOutput->IsOpen()) {
    std::cerr<<"Failed to open file '"<<outputFileName<<"', check permissions on directory and disk space!"<<std::endl;
    throw;
  }

  //set tree to belong to output file
  fTree.SetDirectory(fOutput);

  //create branches for output tree
  fGriffin = new std::vector<Detector>;
  fGriffinBgo = new std::vector<Detector>;
  fTree.Branch("Griffin",&fGriffin, fSettings->BufferSize());
  fTree.Branch("GriffinBgo",&fGriffinBgo, fSettings->BufferSize());
}

Converter::~Converter() {
  if(fOutput->IsOpen()) {
    fTree.Write("tree");
    for(auto& list : fHistograms) {	
      fOutput->mkdir(list.first.c_str());
      fOutput->cd(list.first.c_str());
      list.second->Write();
    }
    fOutput->Close();
  }
}

bool Converter::Run() {
  int status;
  int eventNumber = 0;
  double smearedEnergy;
  std::map<int,int> belowThreshold;
  TH1F* hist1D;
  TH2F* hist2D;
  long int nEntries = fChain.GetEntries();
  for(int i = 0; i < nEntries; ++i) {
    status = fChain.GetEntry(i);
    if(status == -1) {
      std::cerr<<"Error occured, couldn't read entry "<<i<<" from tree "<<fChain.GetName()<<" in file "<<fChain.GetFile()->GetName()<<std::endl;
      continue;
    } else if(status == 0) {
      std::cerr<<"Error occured, entry "<<i<<" in tree "<<fChain.GetName()<<" in file "<<fChain.GetFile()->GetName()<<" doesn't exist"<<std::endl;
      return false;
    }

    //if this entry is from the next event, we fill the tree with everything we've collected so far (after supression) and reset the vector(s)
    if(fEventNumber != eventNumber) {
      Supress();
      fTree.Fill();

      //fill multiplicity histogram
      hist1D = Get1DHistogram("GriffinMultiplicity","Statistics");
      hist1D->Fill(fGriffin->size());
      hist1D = Get1DHistogram("GriffinBgoMultiplicity","Statistics");
      hist1D->Fill(fGriffinBgo->size());

      for(size_t firstDet = 0; firstDet < fGriffin->size(); ++firstDet) {
	hist1D = Get1DHistogram("GriffinSum","Griffin1D");
	hist1D->Fill(fGriffin->at(firstDet).Energy());
	for(size_t secondDet = ++firstDet; secondDet < fGriffin->size(); ++secondDet) {
	  hist2D = Get2DHistogram("GriffinMatrix","Griffin2D");
	  hist2D->Fill(fGriffin->at(firstDet).Energy(),fGriffin->at(secondDet).Energy());
	}
      }

      fGriffin->clear();
      fGriffinBgo->clear();
      eventNumber = fEventNumber;
      belowThreshold.clear();
    }

    //create energy-resolution smeared energy
    smearedEnergy = fRandom.Gaus(fDepEnergy,fSettings->Resolution(fSystemID,fDetNumber,fCryNumber));

    //if the hit is above the threshold, we add it to the vector
    if(AboveThreshold(smearedEnergy)) {
      switch(fSystemID) {
      case 1000:
	fGriffin->push_back(Detector(fEventNumber, fDetNumber, fCryNumber, fDepEnergy, smearedEnergy, TVector3(fPosx,fPosy,fPosz), fTime));
	break;
      case 1100:
      case 1200:
      case 1300:
      case 1400:
      case 1500:
	fGriffinBgo->push_back(Detector(fEventNumber, fDetNumber, fCryNumber, fDepEnergy, smearedEnergy, TVector3(fPosx,fPosy,fPosz), fTime));
	break;
      default:
	std::cerr<<"Unknown detector system ID "<<fSystemID<<std::endl;
	break;
      }
    } else {
      ++belowThreshold[fSystemID];
    }

    if(i%1000 == 0 && fSettings->VerbosityLevel() > 0) {
      std::cout<<std::setw(3)<<100*i/nEntries<<"% done\r"<<std::flush;
    }
  }

  if(fSettings->VerbosityLevel() > 0) {
    std::cout<<"100% done"<<std::endl;

    if(fSettings->VerbosityLevel() > 1) {
      PrintStatistics();
    }
  }  

  return true;
}

bool Converter::AboveThreshold(double energy) {
  if(energy > fSettings->Threshold(fSystemID,fDetNumber,fCryNumber)+10*fSettings->ThresholdWidth(fSystemID,fDetNumber,fCryNumber)) {
    return true;
  }

  if(fRandom.Uniform(0.,1.) < 0.5*(TMath::Erf((energy-fSettings->Threshold(fSystemID,fDetNumber,fCryNumber))/fSettings->ThresholdWidth(fSystemID,fDetNumber,fCryNumber))+1)) {
    return true;
  }

  return false;  
}

void Converter::Supress() {
  //loop over all bgo's and remove all matching germaniums
  for(auto& bgo : *fGriffinBgo) {
    for(auto ge = fGriffin->begin(); ge != fGriffin->end();) {
      if(bgo.DetectorId() == ge->DetectorId()) {
	ge = fGriffin->erase(ge);
      } else {
	++ge;
      }
    }
  }
}

void Converter::PrintStatistics() {

}

TH1F* Converter::Get1DHistogram(std::string histogramName, std::string directoryName) {
  //try and find this histogram
  TH1F* hist = (TH1F*) gDirectory->FindObjectAny(histogramName.c_str());
  if(hist == nullptr){
    //if the histogram doesn't exist, we create it and add it to the histogram list
    hist = new TH1F(histogramName.c_str(),histogramName.c_str(),fSettings->NofBins(directoryName),fSettings->RangeLow(directoryName),fSettings->RangeHigh(directoryName));
    if(fHistograms.find(directoryName) == fHistograms.end()) {
      fHistograms[directoryName] = new TList;
    }
    fHistograms[directoryName]->Add((TObject*) hist);
  }

  return hist;
}

TH2F* Converter::Get2DHistogram(std::string histogramName, std::string directoryName) {
  //try and find this histogram
  TH2F* hist = (TH2F*) gDirectory->FindObjectAny(histogramName.c_str());
  if(hist == nullptr){
    //if the histogram doesn't exist, we create it and add it to the histogram list
    hist = new TH2F(histogramName.c_str(),histogramName.c_str(),
		    fSettings->NofBins(directoryName),fSettings->RangeLow(directoryName),fSettings->RangeHigh(directoryName),
		    fSettings->NofBins(directoryName),fSettings->RangeLow(directoryName),fSettings->RangeHigh(directoryName));
    if(fHistograms.find(directoryName) == fHistograms.end()) {
      fHistograms[directoryName] = new TList;
    }
    fHistograms[directoryName]->Add((TObject*) hist);
  }

  return hist;
}
